#ifndef _NP_VER_H_
#define _NP_VER_H_
#define NPREAL_VERSION "Ver6.0"
#define NPREAL_BUILD "Build 23032913"
#endif
